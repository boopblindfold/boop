from django.apps import AppConfig


class OutlookConfig(AppConfig):
    name = 'Outlook'
